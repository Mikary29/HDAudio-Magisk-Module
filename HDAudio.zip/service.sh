#!/system/bin/sh
# This script should be named 'service.sh' inside your Magisk module folder.

# 1. Wait for the boot sequence to stabilize completely
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 2
done

# 2. Inject SELinux permissions directly into the running kernel
# App IPC Communication with Audio Server
magiskpolicy --live "allow untrusted_app audioserver binder call"
magiskpolicy --live "allow untrusted_app audioserver binder transfer"
magiskpolicy --live "allow priv_app audioserver binder call"
magiskpolicy --live "allow priv_app audioserver binder transfer"

magiskpolicy --live "allow audioserver untrusted_app binder call"
magiskpolicy --live "allow audioserver priv_app binder call"

# Service Discovery Rules
magiskpolicy --live "allow untrusted_app audioserver_service service_manager find"
magiskpolicy --live "allow untrusted_app audio_service service_manager find"
magiskpolicy --live "allow priv_app audioserver_service service_manager find"
magiskpolicy --live "allow priv_app audio_service service_manager find"

# Library Loading, Mapping, and Execution Rules
magiskpolicy --live "allow audioserver same_process_hal_file file execute"
magiskpolicy --live "allow audioserver same_process_hal_file file read"
magiskpolicy --live "allow audioserver same_process_hal_file file open"
magiskpolicy --live "allow audioserver same_process_hal_file file getattr"
magiskpolicy --live "allow audioserver same_process_hal_file file map"
