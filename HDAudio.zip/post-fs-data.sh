#!/system/bin/sh
MODDIR=${0%/*}

# 1. Fix SELinux context for the library
# This is required so 'audioserver' (which has a very restricted SELinux domain) 
# can load your custom code.
chcon -R u:object_r:vendor_file:s0 "$MODDIR/system/vendor/lib64/soundfx"
chcon u:object_r:vendor_file:s0 "$MODDIR/system/vendor/lib64/soundfx/libhdaudioeffect.so"

# 2. Fix SELinux contexts for the config files
# Pixel 8 uses 'audio_effects_config.xml'. We apply labels to both naming variants.
# Using 'vendor_configs_file' is the standard for the vendor partition.
chcon -R u:object_r:vendor_configs_file:s0 "$MODDIR/system/vendor/etc"
chcon u:object_r:vendor_configs_file:s0 "$MODDIR/system/vendor/etc/audio_effects_config.xml"

chcon -R u:object_r:system_file:s0 "$MODDIR/system/priv-app/HDAudio"
chcon u:object_r:system_file:s0 "$MODDIR/system/priv-app/HDAudio/HDAudio.apk"

chcon -R u:object_r:system_file:s0 "$MODDIR/system/etc/sysconfig"
chcon u:object_r:system_file:s0 "$MODDIR/system/etc/sysconfig/com.michael.hdaudio.xml"

chcon -R u:object_r:system_file:s0 "$MODDIR/system/etc/permissions"
chcon u:object_r:system_file:s0 "$MODDIR/system/etc/permissions/privapp-permissions-michael.xml"
